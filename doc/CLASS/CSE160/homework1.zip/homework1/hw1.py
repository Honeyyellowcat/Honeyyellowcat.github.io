"""
* Name:
* Date:
* CSE 160, Winter 2024
* Homework 1
* Description:
"""

# Uncomment the line below to make the math.sqrt function available
# import math

# Problem 1
print("Problem 1 solution follows:")

# Problem 2
print("Problem 2 solution follows:")

# Problem 3
print("Problem 3 solution follows:")

# Provided partially-working solution to problem 3
# `...` are placeholders and should be replaced
n = 10
triangular = 0
for i in ...:
    triangular = ...
print("Triangular number", n, "via loop:", triangular)
print("Triangular number", n, "via formula:", n * (n + 1) / 2)

# Problem 4
print("Problem 4 solution follows:")

# Problem 5
print("Problem 5 solution follows:")

# Problem 6
print("Problem 6 solution follows:")
